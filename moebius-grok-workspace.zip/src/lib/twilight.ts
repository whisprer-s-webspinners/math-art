/** Matplotlib-style twilight, sampled as linear-light RGB. Cyclic: t=0 and t=1 meet. */

const STOPS: ReadonlyArray<readonly [number, number, number, number]> = [
  [0.0, 0.137, 0.071, 0.243],
  [0.08, 0.31, 0.11, 0.45],
  [0.16, 0.58, 0.17, 0.5],
  [0.24, 0.8, 0.3, 0.47],
  [0.32, 0.91, 0.5, 0.45],
  [0.4, 0.94, 0.73, 0.55],
  [0.48, 0.86, 0.87, 0.72],
  [0.56, 0.58, 0.85, 0.8],
  [0.64, 0.26, 0.68, 0.76],
  [0.72, 0.12, 0.44, 0.64],
  [0.8, 0.09, 0.24, 0.48],
  [0.88, 0.09, 0.12, 0.33],
  [0.94, 0.11, 0.075, 0.26],
  [1.0, 0.137, 0.071, 0.243],
];

function smooth(u: number): number {
  return u * u * (3 - 2 * u);
}

/** sRGB twilight at t in [0, 1]. */
export function twilight(t: number): [number, number, number] {
  const x = ((t % 1) + 1) % 1;
  let i = 0;
  while (i < STOPS.length - 2 && STOPS[i + 1][0] < x) i++;
  const a = STOPS[i];
  const b = STOPS[i + 1];
  const u = smooth((x - a[0]) / (b[0] - a[0]));
  return [a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u, a[3] + (b[3] - a[3]) * u];
}

/** twilight_shifted: the dark join sits at the middle of the range. */
export function twilightShifted(t: number): [number, number, number] {
  return twilight(t + 0.5);
}
