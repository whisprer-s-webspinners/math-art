export const vertexShader = /* glsl */ `
attribute float aU;
attribute float aV;
varying float vU;
varying float vV;
varying vec3 vN;
varying vec3 vWorld;

void main() {
  vU = aU;
  vV = aV;

  float u = aU;
  float v = aV;
  float c = cos(u * 0.5);
  float s = sin(u * 0.5);
  float cu = cos(u);
  float su = sin(u);
  float R = 1.0 + v * c;
  float Ru = -0.5 * v * s;

  vec3 dPu = vec3(Ru * cu - R * su, Ru * su + R * cu, 0.5 * v * c);
  vec3 dPv = vec3(c * cu, c * su, s);
  vec3 nMath = cross(dPu, dPv);
  float nLen = length(nMath);
  vec3 nUnit = nLen > 1e-5 ? nMath / nLen : vec3(0.0, 0.0, 1.0);
  vec3 nYup = vec3(nUnit.x, nUnit.z, -nUnit.y);
  vN = normalize(mat3(modelMatrix) * nYup);

  vec4 world = modelMatrix * vec4(position, 1.0);
  vWorld = world.xyz;
  gl_Position = projectionMatrix * viewMatrix * world;
}
`;

export const fragmentShader = /* glsl */ `
uniform float uPhase;
uniform sampler2D uMap;
varying float vU;
varying float vV;
varying vec3 vN;
varying vec3 vWorld;

void main() {
  float field = 0.5 * (
    sin(9.0 * vU + 7.0 * vV + uPhase) +
    cos(13.0 * vU - 11.0 * vV - uPhase)
  );
  float t = clamp(field * 0.5 + 0.5, 0.0, 1.0);
  vec3 base = texture2D(uMap, vec2(fract(t + 0.5), 0.5)).rgb;

  vec3 N = normalize(vN);
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 L = normalize(vec3(0.42, 0.86, 0.28));
  float ndl = abs(dot(N, L));
  float ndv = abs(dot(N, V));
  float rim = pow(1.0 - ndv, 2.05);
  float edge = smoothstep(0.26, 0.48, abs(vV));

  vec3 col = base * (0.8 + 0.22 * ndl);
  col += base * rim * 0.42;
  col += vec3(0.95, 0.86, 0.7) * edge * (0.1 + rim * 0.38);

  gl_FragColor = vec4(col, 1.0);
}
`;
