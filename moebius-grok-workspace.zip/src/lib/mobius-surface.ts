/** Half-width of the strip, matching the original plot. */
export const HALF_WIDTH = 0.48;

export type StripBuffers = {
  positions: Float32Array;
  paramU: Float32Array;
  paramV: Float32Array;
  indices: Uint32Array;
  nu: number;
  nv: number;
};

/**
 * Möbius strip.
 * x = (1 + v cos(u/2)) cos u
 * y = (1 + v cos(u/2)) sin u
 * z = v sin(u/2)
 *
 * u runs [0, 2π) once. The seam stitches (u → 2π, v) to (u = 0, −v),
 * which is the same point in space — one surface, one edge.
 * Positions are Y-up: math (x, y, z) → (x, z, −y), so the ring lies flat
 * and a turn about Y is a turntable spin.
 */
export function mobiusPoint(u: number, v: number): [number, number, number] {
  const c = Math.cos(u * 0.5);
  const radius = 1 + v * c;
  const x = radius * Math.cos(u);
  const y = radius * Math.sin(u);
  const z = v * Math.sin(u * 0.5);
  return [x, z, -y];
}

export function buildStrip(nu: number, nv: number): StripBuffers {
  const count = nu * nv;
  const positions = new Float32Array(count * 3);
  const paramU = new Float32Array(count);
  const paramV = new Float32Array(count);
  const twoPi = Math.PI * 2;

  for (let i = 0; i < nu; i++) {
    const u = (i / nu) * twoPi;
    for (let j = 0; j < nv; j++) {
      const v = -HALF_WIDTH + (j / (nv - 1)) * (HALF_WIDTH * 2);
      const [x, y, z] = mobiusPoint(u, v);
      const k = i * nv + j;
      positions[k * 3] = x;
      positions[k * 3 + 1] = y;
      positions[k * 3 + 2] = z;
      paramU[k] = u;
      paramV[k] = v;
    }
  }

  const indices = new Uint32Array(nu * (nv - 1) * 6);
  let p = 0;
  for (let i = 0; i < nu; i++) {
    const i2 = (i + 1) % nu;
    const wrap = i2 === 0;
    for (let j = 0; j < nv - 1; j++) {
      const a = i * nv + j;
      const c = i * nv + j + 1;
      const b = wrap ? jMirror(0, nv, j) : i2 * nv + j;
      const d = wrap ? jMirror(0, nv, j + 1) : i2 * nv + j + 1;
      indices[p++] = a;
      indices[p++] = b;
      indices[p++] = d;
      indices[p++] = a;
      indices[p++] = d;
      indices[p++] = c;
    }
  }

  return { positions, paramU, paramV, indices, nu, nv };
}

function jMirror(iBase: number, nv: number, j: number): number {
  return iBase * nv + (nv - 1 - j);
}

/** Samples across the seam: (2π, v) and (0, −v) are one point. */
export function seamError(v: number): number {
  const a = mobiusPoint(Math.PI * 2, v);
  const b = mobiusPoint(0, -v);
  return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
}
